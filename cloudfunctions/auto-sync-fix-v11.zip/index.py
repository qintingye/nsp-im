"""NSP-IM v3.0 实时自动同步（CloudBase 函数）

每 30 分钟跑一次：
1. HTTP 读 NSP-IM policies.json（最新政策）—— 从 CloudBase 静态托管
2. HTTP 读 projects.json（25 项目）
3. HTTP 读 today.json（今日数据）
4. HTTP 读 index.html 当模板（最新部署版）
5. 生成 HTML（替换 TODAY 数据）
6. 上传到 CloudBase 静态托管

D46 变更：
- ❌ 移除 `import requests`（CloudBase Python 3.11 不内置）
- ✅ 改用标准库 `urllib.request`（Python 内置，零依赖）
- ✅ 上传继续用 `http.client`（也是标准库）
- ✅ 不再需要 requirements.txt

D47 变更：
- ❌ 去除 URL 中的 `/liuwang-jiankong` 前缀（这是 CloudBase 内部"应用路径"路由，不应出现在 URL 里）
- ✅ 真实 URL：`https://{ENV_ID}.tcloudbaseapp.com/data/{name}`（直接走根路径）

D48 变更：
- ❌ 默认域名 `liwang-jiankong-...tcloudbaseapp.com` 返回 HTTP 418（CloudBase 默认域名服务不可用）
- ✅ 改用自定义域名 `liwangqingbaozhan-liuwang-jiankong-...webapps.tcloudbaseapp.com`（V3.0 正常 200）
- ✅ 真实 URL：`https://{CUSTOM_DOMAIN}/liuwang-jiankong/{path}`（自定义域名路径含应用路径）

D49 变更：
- ❌ 自定义域名 `https://liwangqingbaozhan-...tcloudbaseapp.com` → SSL: CERTIFICATE_VERIFY_FAILED（证书不匹配）
- ❌ 默认域名 `https://liwang-jiankong-...tcloudbaseapp.com` → HTTP 418（部分路径 200）
- ✅ **CloudBase 函数 outbound 走腾讯内网 —— 直接 HTTP 80 端口（无证书验证）**
- ✅ URL 改用 `http://{CUSTOM_DOMAIN}/liuwang-jiankong/{path}` + `ssl._create_unverified_context()`
- ✅ 自定义域名浏览器能正常 V3.0 渲染（用户已验证），HTTP 走内网同理
"""
import os
import json
import ssl
import http.client
import urllib.request
from datetime import datetime


# CloudBase 环境 ID + 静态托管基址
# D48: 默认域名 418，改用自定义域名 `liwangqingbaozhan-...`（V3.0 验证 200）
ENV_ID = 'liwang-jiankong-d2eatyj479b1861-1471069936'
CUSTOM_DOMAIN_HOST = 'liwangqingbaozhan-liuwang-jiankong-d2eatyj479b1861.webapps.tcloudbaseapp.com'
# D49: 走 HTTP 80 端口（内网，无证书验证问题）+ unverified context（万一遇到重定向到 HTTPS）
STATIC_BASE_HTTP = f'http://{CUSTOM_DOMAIN_HOST}/liuwang-jiankong'


def _unverified_ctx():
    """返回跳过证书验证的 SSL context（D49：自定义域名 SSL 证书不匹配）"""
    return ssl._create_unverified_context()


def fetch_json(name):
    """HTTP GET 读 JSON（HTTP 80 端口 + unverified context，D49 走内网）"""
    url = f'{STATIC_BASE_HTTP}/data/{name}'
    req = urllib.request.Request(
        url,
        headers={'User-Agent': 'NSP-IM-Trigger/1.0'},
    )
    with urllib.request.urlopen(req, timeout=10, context=_unverified_ctx()) as r:
        return json.loads(r.read().decode('utf-8'))


def fetch_html():
    """HTTP GET 读 index.html 模板（HTTP 80 端口 + unverified context，D49 走内网）"""
    url = f'{STATIC_BASE_HTTP}/index.html'
    req = urllib.request.Request(
        url,
        headers={'User-Agent': 'NSP-IM-Trigger/1.0'},
    )
    with urllib.request.urlopen(req, timeout=10, context=_unverified_ctx()) as r:
        return r.read().decode('utf-8')


def main_handler(event, context):
    print(f"=== V3.0 自动同步 {datetime.now().isoformat()} ===")

    try:
        # 1. HTTP 读数据（不再依赖 ./data/，避免云端工作目录无 data/）
        projects_doc = fetch_json('projects.json')
        # projects.json 是 { version, generated_at, projects: [...] } 结构
        projects = (
            projects_doc['projects']
            if isinstance(projects_doc, dict) and 'projects' in projects_doc
            else projects_doc
        )
        policies_doc = fetch_json('policies.json')
        # policies.json 是 { version, generated_at, policies: [...] } 结构
        policies = (
            policies_doc['policies']
            if isinstance(policies_doc, dict) and 'policies' in policies_doc
            else policies_doc
        )
        today = fetch_json('today.json')

        # 2. 模板直接用 index.html（最新部署版，含 V3.0 全部功能）
        html = fetch_html()

        print(f"✓ 抓取 policies: {len(policies)} 条")
        print(f"✓ 抓取 projects: {len(projects)} 条")
        print(f"✓ 抓取 today: {today.get('date', '?')}")
        print(f"✓ 模板读取: {len(html)} bytes")

        # 3. 注入最新数据
        def _date_key(p):
            return p.get('publish_date', '') or p.get('date', '') or ''

        recent_policies = sorted(policies, key=_date_key, reverse=True)[:5]
        today_data = {
            'date': today.get('date', datetime.now().strftime('%Y-%m-%d')),
            'generated_at': datetime.now().isoformat(),
            'total': len(policies),
            'items': recent_policies,
        }

        # 替换模板占位符
        html = html.replace(
            '/*__TODAY__*/',
            'const TODAY = ' + json.dumps(today_data, ensure_ascii=False) + ';',
        )
        html = html.replace(
            '/*__PROJECTS__*/',
            'const PROJECTS = ' + json.dumps(projects, ensure_ascii=False) + ';',
        )
        html = html.replace(
            '/*__BUILD_TIME__*/',
            "'" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + "'",
        )

        print(f"✓ HTML 生成: {len(html)} bytes")

        # 4. 上传到 CloudBase 静态托管（http.client 标准库，无需 requests）
        boundary = '----NSP-IM-Boundary'
        body = (
            f'--{boundary}\r\n'
            f'Content-Disposition: form-data; name="file"; filename="index.html"\r\n'
            f'Content-Type: text/html\r\n\r\n'
        ).encode('utf-8') + html.encode('utf-8') + f'\r\n--{boundary}--\r\n'.encode('utf-8')

        headers = {
            'Content-Type': f'multipart/form-data; boundary={boundary}',
            'Content-Length': str(len(body)),
        }

        conn = http.client.HTTPSConnection(f'{ENV_ID}.api.tcloudbaseapp.com')
        conn.request('POST', '/v1/upload?path=/index.html', body=body, headers=headers)
        response = conn.getresponse()
        result = response.read().decode('utf-8')

        if response.status == 200:
            print(f"✓ 上传成功")
            return {
                'code': 0,
                'msg': f'同步成功：{len(policies)} 条政策',
                'total': len(policies),
                'projects': len(projects),
                'upload_status': response.status,
                'html_bytes': len(html),
                'upload_response': result[:200],
            }
        else:
            print(f"⚠️ 上传响应 {response.status}: {result[:200]}")
            return {
                'code': response.status,
                'msg': f'上传失败：{response.status}',
                'total': len(policies),
                'projects': len(projects),
                'html_bytes': len(html),
                'upload_response': result[:200],
            }
    except Exception as e:
        print(f"✗ 同步失败: {e}")
        import traceback
        traceback.print_exc()
        return {
            'code': 500,
            'msg': f'同步失败：{str(e)}',
        }
